<template>
  <h1>Bye!</h1>
</template>
