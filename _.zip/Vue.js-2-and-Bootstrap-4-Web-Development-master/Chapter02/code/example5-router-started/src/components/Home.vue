<template>
  <h1>Welcome to your application</h1>
</template>
