<template>
  <div>
    <pomodoro-timer></pomodoro-timer>
  </div>
</template>
<script>
  import {PomodoroTimer} from './sections'
  export default {
    components: {
      PomodoroTimer
    }
  }
</script>
<style scoped lang="sass">

</style>
