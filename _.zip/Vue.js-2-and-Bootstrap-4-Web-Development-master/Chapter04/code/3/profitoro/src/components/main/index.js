export {default as ContentComponent} from './ContentComponent'
export {default as FooterComponent} from './FooterComponent'
export {default as HeaderComponent} from './HeaderComponent'

