export default {
  workingPomodoro: 0.2,
  shortBreak: 5,
  longBreak: 10,
  pomodorosTillLongBreak: 3
}
