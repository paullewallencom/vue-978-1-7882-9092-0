describe('test.js', () => {
  describe('hello', () => {
    it('should say hello', () => {
      expect('hello').to.eql('hello')
    })
  })
})
