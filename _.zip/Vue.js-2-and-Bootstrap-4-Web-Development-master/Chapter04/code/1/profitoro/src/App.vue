<template>
  <div id="app">
    <h1>Welcome to Profitoro</h1>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
</style>
