<template>
  <div>
    <count-down-timer></count-down-timer>
  </div>
</template>
<script>
  import CountDownTimer from './timer/CountDownTimer'
  export default {
    components: {
      CountDownTimer
    }
  }
</script>
<style scoped lang="scss">

</style>
