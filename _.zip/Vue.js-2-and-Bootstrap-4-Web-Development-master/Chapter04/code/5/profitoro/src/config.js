export default {
  workingPomodoro: 2,
  shortBreak: 1,
  longBreak: 1,
  pomodorosTillLongBreak: 3
}
