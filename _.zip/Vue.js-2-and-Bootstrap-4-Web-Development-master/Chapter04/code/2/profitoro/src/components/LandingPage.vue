<template>
  <div>Landing Page</div>
</template>
<script>
  export default {

  }
</script>
<style scoped lang="sass">

</style>
