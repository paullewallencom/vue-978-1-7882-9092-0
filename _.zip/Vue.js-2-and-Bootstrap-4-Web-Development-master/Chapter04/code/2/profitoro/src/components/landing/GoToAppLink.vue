<template>
  <div>Go To App</div>
</template>
<script>
  export default {

  }
</script>
<style scoped lang="sass">

</style>

